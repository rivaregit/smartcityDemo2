"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CredentialsUserResponse = void 0;
class CredentialsUserResponse {
    constructor() {
        this.email = '';
        this.code = '';
        this.username = "";
        this.sucessed = "0";
        this.token = "";
    }
}
exports.CredentialsUserResponse = CredentialsUserResponse;
